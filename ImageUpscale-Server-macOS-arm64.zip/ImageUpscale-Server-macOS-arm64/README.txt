ImageUpscale for macOS (local server edition)
=============================================

ImageUpscale makes photos 2x or 4x bigger with Real-ESRGAN, a neural network that adds detail.
It runs entirely on this Mac. Your pictures are never uploaded anywhere.

Version 1.0.0

NOTE: this build has been checked on Linux only, not yet on a real Mac. If something does not
work, see TROUBLESHOOTING and copy any text the Terminal window shows.


WHICH ZIP TO USE
----------------
- ImageUpscale-Server-macOS-arm64.zip: Macs with Apple silicon (M1, M2, M3, M4 and later).
  If "About This Mac" says "Chip: Apple M..." this is yours.
- ImageUpscale-Server-macOS-x64.zip: Intel Macs. If it says "Processor: Intel" this is yours.

Not sure? Apple menu, About This Mac. If you see "Chip", use arm64. If you see "Processor", use x64.


WHAT YOU NEED
-------------
- A recent macOS (12 Monterey or later is expected to work).
- About 300 MB of free disk space. The optional Quality model adds 64 MB.
- A web browser: Safari, Chrome or Firefox.
- Nothing else. No installer, no admin password, no Node.js. Everything needed is in this folder.


HOW TO START (first time)
-------------------------
1. Unzip the file. Double-click it in Finder. A folder with the same name appears.
   Move the folder somewhere you keep apps, such as Documents or Applications.

2. Open the folder and double-click "Start ImageUpscale.command".

3. The first time, macOS will refuse, because the file is not signed by an Apple developer:
   - Right-click (or Control-click) "Start ImageUpscale.command" and choose "Open".
   - Click "Open" in the warning box.
   Only needed once.

   If that does not work, open System Settings, go to Privacy & Security, scroll down to the
   message about "Start ImageUpscale.command" and click "Open Anyway". Then open it again.

   Still blocked? Open Terminal, type "xattr -dr com.apple.quarantine " (with a space at the end),
   drag the ImageUpscale folder into the Terminal window, press Return, then start the file again.

4. A Terminal window opens and your browser opens the app. If the browser does not open by itself,
   type this address into it:

       http://127.0.0.1:4317/

5. Keep the Terminal window open while you use the app. Closing it stops the app.


HOW TO USE IT
-------------
1. Drop an image onto the page, or click "Open Images..." (shortcut: Command+O).
   PNG, JPEG, WebP, BMP, TIFF, GIF and AVIF all work. You can add several at once.
2. Choose 2x or 4x at the top.
3. Choose a model:
   - Fast (the default): right for most photos. Built in, nothing to download.
   - Quality: sharper on some photos, but much slower. The first time you choose it, click
     Download (64 MB, once). Downloads can be paused and resumed.
4. Click Upscale (shortcut: Command+Return). Cancel stops it. Esc also cancels.
5. Drag the slider across the picture to compare before and after.
6. Choose the file format at the bottom: PNG keeps everything, JPEG and WebP are smaller.
7. Click Save (shortcut: Command+S). Your browser downloads the picture, normally into your
   Downloads folder. Save All (shortcut: Command+Shift+S) downloads every finished picture.


HOW LONG IT TAKES
-----------------
On a 4-core Linux test machine, Fast took roughly 15 seconds per megapixel of input, so a
2-megapixel photo takes about 30 seconds. Quality took about 12 times longer. These were not
measured on a Mac, so your times will differ.


LIMITS
------
- Pictures up to about 16 megapixels can be made 4x bigger (about 64 megapixels at 2x).
  Bigger pictures are refused with a message. Crop or shrink them first.
- The upscaler invents detail. Small text, faces and fine patterns can change shape.
  Do not rely on it where the exact detail matters.
- Animated GIFs: only the first frame is upscaled.
- WebP files can be at most 16,383 pixels on a side. Use PNG for very large results.


STOPPING IT
-----------
Close the Terminal window, or press Control+C in it. Then close the browser tab.


PRIVACY
-------
- The app only listens on this Mac (address 127.0.0.1). Other computers, including ones on your
  own network, cannot connect to it.
- While you work, pictures are copied into a temporary folder. That folder is emptied when the
  app stops.
- The only internet use is the optional Quality model download, from huggingface.co.
  The Fast model needs no internet at all.
- There is no password. Do not change the HOST setting to 0.0.0.0, because that would make the
  app reachable from your network.


TROUBLESHOOTING
---------------
"Start ImageUpscale.command" cannot be opened, or "is damaged"
    See step 3 above. The quarantine fix in Terminal resolves it.

Terminal closes straight away
    Usually the zip was opened in a way that left the files behind, or the download was damaged.
    Unzip it again to a normal folder and open the file from there.

"Port 4317 is already in use", or the page does not load
    Another copy is still running. Close its Terminal window, or use another port: open
    Terminal, type  PORT=4400  then drag "Start ImageUpscale.command" into the window and press
    Return. Then open  http://127.0.0.1:4400/  in your browser.

macOS asks whether to allow incoming connections for "node"
    Either choice works. The app only listens on this Mac, so it does not need network access.

"The Quality model is not downloaded yet"
    Choose Quality, then click Download. If it stops part way, click Download again.
    It resumes where it left off.

"This picture is too large"
    Crop it, or shrink it, and try again.

"not a supported image" or "could not be read"
    Save the picture as PNG or JPEG and try again.

It is very slow
    That is normal for Quality, and for large pictures. Use Fast, or make the picture smaller.


UNINSTALL
---------
Close the app, then move the folder to the Trash.
Your settings and the Quality model are stored in  ~/.ImageUpscale  (your home folder, hidden).
Delete that folder too if you want to remove everything. In Finder press Command+Shift+G and
type  ~/.ImageUpscale  to find it.


WHAT IS IN THIS FOLDER
----------------------
Start ImageUpscale.command   starts the app
node/node                    Node.js 22, the runtime the app runs on (checksum verified when packed)
app/                         the app: server, web page, upscaler, Fast model, and the macOS native
                             libraries (ONNX Runtime, sharp with libvips)
README.txt                   this file
