#!/bin/bash
# ImageUpscale launcher for macOS. Double-click this file in Finder.
cd "$(dirname "$0")" || exit 1
NODE="$PWD/node/node"
if [ ! -x "$NODE" ] || [ ! -d "$PWD/app" ]; then
  echo "This folder is incomplete, so ImageUpscale cannot start."
  echo "Unzip the file again to a normal folder, then open this file from there."
  read -r -n 1 -p "Press any key to close."; echo; exit 1
fi
PORT="${PORT:-4317}"
echo "Starting ImageUpscale. Your browser will open to the app."
echo "Keep this window open while you use it. Close it to stop."
echo "If the browser does not open, go to http://127.0.0.1:$PORT/"
echo
cd "$PWD/app" && PORT="$PORT" "$NODE" server/server.js --open
echo
echo "ImageUpscale stopped. If this was not on purpose, read the message above."
read -r -n 1 -p "Press any key to close."; echo
